// Copyright 2022 PyMatching Contributors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef PYMATCHING_STRUCTURED_SEARCH_DETECTOR_NODE_H
#define PYMATCHING_STRUCTURED_SEARCH_DETECTOR_NODE_H

#include "pymatching/sparse_blossom/driver/implied_weights.h"
#include "pymatching/sparse_blossom/structured/grid/static_grid.h"
#include "pymatching/sparse_blossom/structured/tracker/queued_event_tracker.h"

namespace pm::structured {

const uint8_t FLIPPED = 1;
const uint8_t WEIGHT_SIGN = 2;

class SearchDetectorNode {
   public:
    size_t edge_slots() const {
        return STRUCTURED_STORAGE_DIRECTIONS;
    }
    bool has_edge(size_t h) const {
        return h < edge_slots() && (grid_component->present[grid_cell] & (uint16_t{1} << h));
    }
    SearchDetectorNode* neighbor(size_t h) const {
        return grid_component->neighbor(grid_cell, h);
    }
    weight_int& edge_weight(size_t h) {
        return grid_component->weights[grid_cell][h];
    }
    weight_int edge_weight(size_t h) const {
        return grid_component->weights[grid_cell][h];
    }
    const std::vector<size_t>& edge_observables(size_t h) const {
        return grid_component->observables[grid_cell][h];
    }
    uint8_t& edge_marker(size_t h) {
        return grid_component->markers[grid_cell][h];
    }
    std::vector<ImpliedWeight>& edge_implied_weights(size_t h) {
        return grid_component->implied_weights[grid_cell * STRUCTURED_STORAGE_DIRECTIONS + h];
    }
    SearchDetectorNode() : reached_from_source(nullptr), index_of_predecessor(SIZE_MAX), distance_from_source(0) {
    }

    /// The SearchDetectorNode that this node was reached from in the Dijkstra search
    SearchDetectorNode* reached_from_source;

    /// `index_of_predecessor` is the index in `neighbors` of the neighboring detector node that this node was
    /// reached from in the Dijkstra search.
    size_t index_of_predecessor;

    /// The distance from the search source detector node that this node was reached from.
    pm::cumulative_time_int distance_from_source;

    /// Manages the next "look at me" event for the node
    QueuedEventTracker node_event_tracker;

    /// == Permanent fields used to define the structure of the graph. ==
    std::vector<SearchDetectorNode*> neighbors;  /// The node's neighbors.
    std::vector<weight_int> neighbor_weights;    /// Distance crossed by the edge to each neighbor.
    std::vector<std::vector<size_t>>
        neighbor_observable_indices;        /// Indices of observables crossed by the edge to each neighbor.
    std::vector<uint8_t> neighbor_markers;  /// Used to mark edges as "seen" when decoding to an edge list.

    std::vector<std::vector<ImpliedWeight>> neighbor_implied_weights;

    StaticGridComponent<SearchDetectorNode, std::vector<size_t>>* grid_component = nullptr;
    size_t grid_cell = 0;
    size_t detector_id = SIZE_MAX;

    size_t index_of_neighbor(SearchDetectorNode* target) const;

    void reset();
};

}  // namespace pm::structured

#endif  // PYMATCHING_STRUCTURED_SEARCH_DETECTOR_NODE_H
